__version__ = '2022-projekt2-1'
